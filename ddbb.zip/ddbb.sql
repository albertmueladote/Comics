-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.1.13-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win32
-- HeidiSQL Versión:             10.1.0.5464
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para comic
CREATE DATABASE IF NOT EXISTS `comic` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `comic`;

-- Volcando estructura para tabla comic.book
CREATE TABLE IF NOT EXISTS `book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  KEY `Índice 1` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla comic.book: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` (`id`, `title`) VALUES
	(1, 'hola');
/*!40000 ALTER TABLE `book` ENABLE KEYS */;

-- Volcando estructura para tabla comic.collection
CREATE TABLE IF NOT EXISTS `collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  KEY `Índice 1` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla comic.collection: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `collection` DISABLE KEYS */;
INSERT INTO `collection` (`id`, `title`, `status`) VALUES
	(1, 'names', 1);
/*!40000 ALTER TABLE `collection` ENABLE KEYS */;

-- Volcando estructura para tabla comic.comic
CREATE TABLE IF NOT EXISTS `comic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collection` int(11) DEFAULT '0',
  `number` int(11) DEFAULT '0',
  `month` int(11) DEFAULT '0',
  `year` int(11) DEFAULT '0',
  KEY `Índice 1` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla comic.comic: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `comic` DISABLE KEYS */;
INSERT INTO `comic` (`id`, `collection`, `number`, `month`, `year`) VALUES
	(134, 1, 1, 12, 2019);
/*!40000 ALTER TABLE `comic` ENABLE KEYS */;

-- Volcando estructura para tabla comic.compilation
CREATE TABLE IF NOT EXISTS `compilation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` int(11) NOT NULL DEFAULT '0',
  `book` int(11) DEFAULT '0',
  `comic` int(11) DEFAULT '0',
  KEY `Índice 1` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla comic.compilation: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `compilation` DISABLE KEYS */;
INSERT INTO `compilation` (`id`, `title`, `book`, `comic`) VALUES
	(1, 0, 1, 1),
	(2, 0, 1, 2);
/*!40000 ALTER TABLE `compilation` ENABLE KEYS */;

-- Volcando estructura para tabla comic.sales
CREATE TABLE IF NOT EXISTS `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comic` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `date` bigint(20) DEFAULT NULL,
  KEY `Índice 1` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla comic.sales: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` (`id`, `comic`, `price`, `date`) VALUES
	(4, 1, 9.95, 1575287848);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;

-- Volcando estructura para tabla comic.status
CREATE TABLE IF NOT EXISTS `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  KEY `Índice 1` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla comic.status: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `status` DISABLE KEYS */;
INSERT INTO `status` (`id`, `title`) VALUES
	(1, 'Indeterminado'),
	(2, 'Completa'),
	(4, 'Incompleta');
/*!40000 ALTER TABLE `status` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
